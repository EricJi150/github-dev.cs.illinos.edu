#include <stdio.h>

int main()
{
	double val1 = 12;
	double val2= 3;
	double res;

	res = val1 / val2;

	printf("%f\n", res);

	return 0;
}
