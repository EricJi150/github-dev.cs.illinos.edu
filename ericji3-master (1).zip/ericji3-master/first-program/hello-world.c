#include <stdio.h>

#define MESSAGE "Hello, x86 world!\n"

int main()
{
	printf(MESSAGE);
return 0;

}
